package application;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;

import application.Main.TabPage;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.beans.binding.Bindings;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.concurrent.Worker.State;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.geometry.Side;
import javafx.print.PageLayout;
import javafx.print.PageOrientation;
import javafx.print.Paper;
import javafx.print.Printer;
import javafx.print.PrinterJob;
import javafx.stage.Modality;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.util.Duration;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.SingleSelectionModel;
import javafx.scene.control.SplitMenuButton;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.control.TabPane.TabClosingPolicy;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.transform.Scale;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebHistory;
import javafx.scene.web.WebView;

public class BrowserPrinter extends Application {
	public static final String DEFAULT_URL = "https://google.com/";
	private final WebView webView = new WebView();
	private WebEngine engine = webView.getEngine();
	// private ArrayList<WebEngine> engines = new ArrayList<WebEngine>();

	private double webZoom = 1;
	private WebHistory history = engine.getHistory();
	private TextField tfTop = new TextField();

	private BorderPane borderPane = new BorderPane();
	private Stage primaryStage;
	private String homePage;
	private String mode;
	private String bookmarksLocation = "bookmarks.txt";
	private HBox toppane = addTopHBox();
	private VBox centerpane = addCenterVBox();
	private HBox bottompane = addBottomHBox();
	TextField tfBookmarkTitle = new TextField();
	TextField tfBookmarkUrl = new TextField();

//	private TabPane tabPane = new TabPane();
//	private SingleSelectionModel<Tab> selectionModel = tabPane.getSelectionModel();

	@Override
	public void start(Stage primaryStage) {

//		Tab landingTab = new Tab();
//		Tab plusTab = new Tab();
//		
//		tabPane.setTabClosingPolicy(TabClosingPolicy.ALL_TABS);
//		tabPane.getTabs().addAll(landingTab, plusTab);
//		
//		Button btnAddNewTab = new Button();
//		ImageView addNewTabIv = new ImageView(new Image(getClass().getResourceAsStream("plus-16.png")));
//		btnAddNewTab.setGraphic(addNewTabIv);
//		plusTab.setGraphic(btnAddNewTab);
//		
//		btnAddNewTab.setOnAction(new EventHandler<ActionEvent>() {
//
//			@Override
//			public void handle(ActionEvent event) {
//				
//				
//			}
//			
//		});

		this.primaryStage = primaryStage;
		// Function to add and display new tabs with default URL display.
		final TabPane tabPane = new TabPane();
		// Preferred Size of TabPane.
		// tabPane.setPrefSize(1365, 768);
		// Placement of TabPane.
		tabPane.setSide(Side.TOP);
		/*
		 * To disable closing of tabs.
		 * tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
		 */
		final Tab newtab = new Tab();
		ImageView addNewTabIv = new ImageView(new Image(getClass().getResourceAsStream("plus-16.png")));
		newtab.setGraphic(addNewTabIv);
		Tooltip ttpnewTab = new Tooltip();
		ttpnewTab.setText("New tab");
		ttpnewTab.setFont(Font.font("Arial", FontWeight.BOLD, 16));
		newtab.setTooltip(ttpnewTab);
		newtab.setClosable(false);
		// Addition of New Tab to the tabpane.
		tabPane.getTabs().addAll(newtab);
		createAndSelectNewTab(tabPane, "Home");
		// Function to add and display new tabs with default URL display.
		tabPane.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Tab>() {
			@Override
			public void changed(ObservableValue<? extends Tab> observable, Tab oldSelectedTab, Tab newSelectedTab) {
				if (newSelectedTab == newtab) {
					Tab tab = new Tab();
					tab.setText("New Tab");
					// WebView - to display, browse web pages.
					WebView webView = new WebView();
					final WebEngine webEngine = webView.getEngine();
					webEngine.load(DEFAULT_URL);
					final TextField urlField = new TextField(DEFAULT_URL);
					webEngine.locationProperty().addListener(new ChangeListener<String>() {
						@Override
						public void changed(ObservableValue<? extends String> observable, String oldValue,
								String newValue) {
							urlField.setText(newValue);
						}
					});
					// Action definition for the Button Go.
					EventHandler<ActionEvent> goAction = new EventHandler<ActionEvent>() {
						@Override
						public void handle(ActionEvent event) {
							webEngine.load(urlField.getText().startsWith("http://") ? urlField.getText()
									: "http://" + urlField.getText());
						}
					};
					urlField.setOnAction(goAction);
					Button goButton = new Button("Go");
					goButton.setDefaultButton(true);
					goButton.setOnAction(goAction);
					// Layout logic
					HBox hBox = new HBox(5);
					HBox topHbox = new HBox();
					// top HBox UI elements
					Button btnBack = createButton("back");
					Button btnForward = createButton("forward");
					Button btnRefresh = createButton("refresh");
					Button btnSave = createButton("save");
					Button btnHome = createButton("home");
					// set the split menu button
					SplitMenuButton splitMenuButton = new SplitMenuButton();
					splitMenuButton.setText("More");
					splitMenuButton.setMinWidth(80);
					MenuItem miHistory = new MenuItem("History");
					MenuItem miZoomIn = new MenuItem("Zoom In");
					MenuItem miZoomOut = new MenuItem("Zoom Out");
					MenuItem miPrint = new MenuItem("Print");
					MenuItem miBookmarks = new MenuItem("Bookmarks");
					splitMenuButton.getItems().addAll(miHistory, miZoomIn, miZoomOut, miPrint, miBookmarks);

					// if click the back button
					btnBack.setOnAction(new EventHandler<ActionEvent>() {
						@Override
						public void handle(ActionEvent event) {
							ObservableList<WebHistory.Entry> entries = history.getEntries();
							if (history.getCurrentIndex() >= 1) {
								history.go(-1);
								tfTop.setText(entries.get(history.getCurrentIndex()).getUrl());
							}
						}
					});

					// if click the forward button
					btnForward.setOnAction(new EventHandler<ActionEvent>() {
						@Override
						public void handle(ActionEvent event) {
							ObservableList<WebHistory.Entry> entries = history.getEntries();
							if (history.getCurrentIndex() < entries.size() - 1) {
								history.go(1);
								tfTop.setText(entries.get(history.getCurrentIndex()).getUrl());
							}
						}
					});
					// if click the refresh button
					btnRefresh.setOnAction(new EventHandler<ActionEvent>() {
						@Override
						public void handle(ActionEvent event) {
							webEngine.reload();
						}
					});
					// if enter key is pressed on topTextField
					urlField.setOnAction(new EventHandler<ActionEvent>() {
						@Override
						public void handle(ActionEvent event) {
							// centerpane.getChildren().setAll(webView);
							webEngine.load("http://" + urlField.getText());
						}
					});
					// if click the save button
					btnSave.setOnAction(new EventHandler<ActionEvent>() {
						@Override
						public void handle(ActionEvent event) {
							final Stage dialog = new Stage();
							dialog.setTitle("Save a bookmark");
							Image dialogIcon = new Image(getClass().getResourceAsStream("bookmark-16.png"));
							dialog.getIcons().add(dialogIcon);
							dialog.initModality(Modality.APPLICATION_MODAL);
							dialog.initOwner(primaryStage);
							VBox dialogVbox = new VBox(20);
							Label lbTitle = new Label("Title");
							Label lbUrl = new Label("URL");
							Button btnSave = new Button("Save");

							tfBookmarkUrl.setText(tfTop.getText());
							btnSave.setOnAction(e -> {
								dialog.close();
								addLine();
							});
							dialogVbox.getChildren().addAll(new Text(""), lbTitle, tfBookmarkTitle, lbUrl,
									tfBookmarkUrl, btnSave);
							dialogVbox.setSpacing(10);
							dialogVbox.setAlignment(Pos.TOP_CENTER);
							Scene dialogScene = new Scene(dialogVbox, 300, 200);
							dialog.setScene(dialogScene);
							dialog.show();

						}

					});
					// if click the home button
					btnHome.setOnAction(new EventHandler<ActionEvent>() {
						@Override
						public void handle(ActionEvent event) {
							// centerpane.getChildren().setAll(addCenterVBox());
							// borderPane.setCenter(addCenterVBox());
						}
					});
					// set zoom in button
					miZoomIn.setOnAction(new EventHandler<ActionEvent>() {
						@Override
						public void handle(ActionEvent event) {
							webZoom += 0.25;
							webView.setZoom(webZoom);
						}
					});
					// set zoom out button
					miZoomOut.setOnAction(new EventHandler<ActionEvent>() {
						@Override
						public void handle(ActionEvent event) {
							webZoom -= 0.25;
							webView.setZoom(webZoom);
						}
					});
					// display the history
					miHistory.setOnAction(new EventHandler<ActionEvent>() {
						@Override
						public void handle(ActionEvent event) {
							ObservableList<WebHistory.Entry> entries = history.getEntries();
							GridPane historyPane = new GridPane();
							historyPane.setAlignment(Pos.CENTER);
							if (history.getEntries().isEmpty()) {
								historyPane.add(new Text("There is no browsing history!"), 0, 0);

							} else {
//                 					historyPane.add(new Text("Title"), 0, 0);
								historyPane.add(new Text("URL"), 1, 0);
								historyPane.add(new Text("Time"), 2, 0);
								for (int i = 0; i < entries.size(); i++) {
//                 						Text title = new Text(entries.get(i).getTitle());
									Text url = new Text(entries.get(i).getUrl());
									Text time = new Text(entries.get(i).getLastVisitedDate().toString());
//                 						historyPane.add(title, 0, i + 1);
									historyPane.add(url, 1, i + 1);
									historyPane.add(time, 2, i + 1);
								}
							}
//                 				centerpane.getChildren().setAll(historyPane);
						}
					});

					// display the bookmarks
					miBookmarks.setOnAction(new EventHandler<ActionEvent>() {
						@Override
						public void handle(ActionEvent event) {
							ArrayList<Bookmark> bookmarks = new ArrayList<Bookmark>();

							BufferedReader file;
							try {
								file = new BufferedReader(new FileReader("bookmarks.txt"));
								String line;

								try {
									while ((line = file.readLine()) != null) {
										bookmarks.add(new Bookmark(line.split(",")[0], line.split(",")[1]));
									}
								} catch (IOException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							} catch (FileNotFoundException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

							GridPane bookmarkPane = new GridPane();
							bookmarkPane.setAlignment(Pos.CENTER);
							if (bookmarks.isEmpty()) {
								bookmarkPane.add(new Text("There is no bookmarks!"), 0, 0);
							} else {
								bookmarkPane.add(new Text("Title"), 0, 0);
								bookmarkPane.add(new Text("URL"), 1, 0);
								for (int i = 0; i < bookmarks.size(); i++) {
									Text title = new Text(bookmarks.get(i).getTitle());
									Text url = new Text(bookmarks.get(i).getUrl());
									bookmarkPane.add(title, 0, i + 1);
									bookmarkPane.add(url, 1, i + 1);

								}

							}
							// centerpane.getChildren().setAll(bookmarkPane);
						}
					});

					// set HBox style and add all
					urlField.setPromptText("Type a URL");
					topHbox.setSpacing(5);
					HBox.setHgrow(urlField, Priority.ALWAYS);
					topHbox.getChildren().addAll(btnBack, btnForward, btnRefresh, urlField, btnSave, btnHome,
							splitMenuButton);

//                         hBox.getChildren().setAll(urlField, goButton);  
//                         HBox.setHgrow(urlField, Priority.ALWAYS);  
					final VBox vBox = new VBox(5);
					vBox.getChildren().setAll(topHbox, webView);
					VBox.setVgrow(webView, Priority.ALWAYS);
					tab.setContent(vBox);
					final ObservableList<Tab> tabs = tabPane.getTabs();
					tab.closableProperty().bind(Bindings.size(tabs).greaterThan(2));
					tabs.add(tabs.size() - 1, tab);
					tabPane.getSelectionModel().select(tab);
				}
			}
		});
		borderPane.setCenter(tabPane);
		Rectangle2D primaryScreenBounds = Screen.getPrimary().getVisualBounds();
		double initialWidth = primaryScreenBounds.getWidth() * 0.8;
		double initialHeight = primaryScreenBounds.getHeight() * 0.8;

		Scene scene = new Scene(borderPane, initialWidth, initialHeight);
		primaryStage.setTitle("Selina Yu's Browser");
		Image iconIm = new Image(getClass().getResourceAsStream("logo-128.png"));
		primaryStage.getIcons().add(iconIm);
		primaryStage.setScene(scene);
		primaryStage.show();
	}

// -------------------------------------------- Top HBox -------------------------------------------------
	public Button createButton(String name) {
		Button btnName = new Button();
		Image imageBtn = new Image(getClass().getResourceAsStream(name + "-16.png"));
		btnName.setGraphic(new ImageView(imageBtn));
		Tooltip ttp = new Tooltip();
		if (name.equals("back") || name.equals("forward")) {
			ttp.setText("Click to go " + name);
		} else if (name.equals("refresh")) {
			ttp.setText("Reload this page");
		} else if (name.equals("save")) {
			ttp.setText("Bookmark this tab");
		} else if (name.equals("customize")) {
			ttp.setText("Customize this page");
		} else if (name.equals("home")) {
			ttp.setText("Go to the homepage");
		}
		ttp.setStyle("-fx-background-color:Grey;");
		btnName.setTooltip(ttp);
		return btnName;
	}

	public HBox addTopHBox() {
		HBox topHbox = new HBox();
		// top HBox UI elements
		Button btnBack = createButton("back");
		Button btnForward = createButton("forward");
		Button btnRefresh = createButton("refresh");
		Button btnSave = createButton("save");
		Button btnHome = createButton("home");
		// set the split menu button
		SplitMenuButton splitMenuButton = new SplitMenuButton();
		splitMenuButton.setText("More");
		splitMenuButton.setMinWidth(80);
		MenuItem miHistory = new MenuItem("History");
		MenuItem miZoomIn = new MenuItem("Zoom In");
		MenuItem miZoomOut = new MenuItem("Zoom Out");
		MenuItem miPrint = new MenuItem("Print");
		MenuItem miBookmarks = new MenuItem("Bookmarks");
		splitMenuButton.getItems().addAll(miHistory, miZoomIn, miZoomOut, miPrint, miBookmarks);
		// set home page
//		homePage = "www.google.com";
//		topTextField.setText(homePage);

		// if click the back button
		btnBack.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				ObservableList<WebHistory.Entry> entries = history.getEntries();
				if (history.getCurrentIndex() >= 1) {
					history.go(-1);
					tfTop.setText(entries.get(history.getCurrentIndex()).getUrl());
				}
			}
		});

		// if click the forward button
		btnForward.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				ObservableList<WebHistory.Entry> entries = history.getEntries();
				if (history.getCurrentIndex() < entries.size() - 1) {
					history.go(1);
					tfTop.setText(entries.get(history.getCurrentIndex()).getUrl());
				}
			}
		});
		// if click the refresh button
		btnRefresh.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				engine.reload();
			}
		});
		// if enter key is pressed on topTextField
		tfTop.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				centerpane.getChildren().setAll(webView);
				engine.load("http://" + tfTop.getText());
			}
		});
		// if click the save button
		btnSave.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				final Stage dialog = new Stage();
				dialog.setTitle("Save a bookmark");
				Image dialogIcon = new Image(getClass().getResourceAsStream("bookmark-16.png"));
				dialog.getIcons().add(dialogIcon);
				dialog.initModality(Modality.APPLICATION_MODAL);
				dialog.initOwner(primaryStage);
				VBox dialogVbox = new VBox(20);
				Label lbTitle = new Label("Title");
				Label lbUrl = new Label("URL");
				Button btnSave = new Button("Save");

				tfBookmarkUrl.setText(tfTop.getText());
				btnSave.setOnAction(e -> {
					dialog.close();
					addLine();
				});
				dialogVbox.getChildren().addAll(new Text(""), lbTitle, tfBookmarkTitle, lbUrl, tfBookmarkUrl, btnSave);
				dialogVbox.setSpacing(10);
				dialogVbox.setAlignment(Pos.TOP_CENTER);
				Scene dialogScene = new Scene(dialogVbox, 300, 200);
				dialog.setScene(dialogScene);
				dialog.show();

			}

		});
		// if click the home button
		btnHome.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				centerpane.getChildren().setAll(addCenterVBox());
				// borderPane.setCenter(addCenterVBox());
			}
		});
		// set zoom in button
		miZoomIn.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				webZoom += 0.25;
				webView.setZoom(webZoom);
			}
		});
		// set zoom out button
		miZoomOut.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				webZoom -= 0.25;
				webView.setZoom(webZoom);
			}
		});
		// set print button
//		miPrint.setOnAction(new EventHandler<ActionEvent>() {
//			@Override
//			public void handle(ActionEvent event) {
//				// print button pressed, page loaded
//				final BooleanProperty printbuttonclickedproperty = new SimpleBooleanProperty(false);
//				final BooleanProperty pageloadedproperty = new SimpleBooleanProperty(false);
//
//				// when the a page is loaded and the button was pressed call the print() method.
//				final BooleanProperty printactionproperty = new SimpleBooleanProperty(false);
//				printactionproperty.bind(pageloadedproperty.and(printbuttonclickedproperty));
//
//				// webengine updates flag when finished loading web page.
//				engine.getLoadWorker().stateProperty()
//						.addListener((ChangeListener<? super State>) (obsvalue, oldstate, newstate) -> {
//							if (newstate == State.SUCCEEDED) {
//								pageloadedproperty.set(true);
//							}
//						});
//
//				// when user enters a url and hits the enter key.
//				tfTop.setOnAction(aevent -> {
//					pageloadedproperty.set(false);
//					printbuttonclickedproperty.set(false);
//					engine.load(tfTop.getText());
//				});
//
//				// when the user clicks the print button the webview node is printed
//				miPrint.setOnAction(aevent -> {
//					printbuttonclickedproperty.set(true);
//				});
//
//				// once the print action hears a true go print the webview node.
////				printactionproperty.addListener((changeListener) (obsvalue, oldstate, newstate) -> {
////					if (newstate) {
////						print(webView);
////					}
////				});
//				printactionproperty.addListener((ChangeListener<? super Boolean>) (obsvalue, oldstate, newstate) -> {
//					if (newstate) {
//						print(webView);
//					}
//				});
//
//			}
//
//			private void print(WebView webView) {
//				// TODO Auto-generated method stub
//				Printer printer = Printer.getDefaultPrinter();
//				PageLayout pageLayout = printer.createPageLayout(Paper.NA_LETTER, PageOrientation.PORTRAIT,
//						Printer.MarginType.DEFAULT);
//				double scalex = pageLayout.getPrintableWidth() / webView.getBoundsInParent().getWidth();
//				double scaley = pageLayout.getPrintableHeight() / webView.getBoundsInParent().getHeight();
//				webView.getTransforms().add(new Scale(scalex, scaley));
//
//				PrinterJob job = PrinterJob.createPrinterJob();
//				if (job != null) {
//					boolean success = job.printPage(webView);
//					if (success) {
//						job.endJob();
//					}
//				}
//			}
//		});
		// display the history
		miHistory.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				ObservableList<WebHistory.Entry> entries = history.getEntries();
				GridPane historyPane = new GridPane();
				historyPane.setAlignment(Pos.CENTER);
				if (history.getEntries().isEmpty()) {
					historyPane.add(new Text("There is no browsing history!"), 0, 0);

				} else {
//					historyPane.add(new Text("Title"), 0, 0);
					historyPane.add(new Text("URL"), 1, 0);
					historyPane.add(new Text("Time"), 2, 0);
					for (int i = 0; i < entries.size(); i++) {
//						Text title = new Text(entries.get(i).getTitle());
						Text url = new Text(entries.get(i).getUrl());
						Text time = new Text(entries.get(i).getLastVisitedDate().toString());
//						historyPane.add(title, 0, i + 1);
						historyPane.add(url, 1, i + 1);
						historyPane.add(time, 2, i + 1);
					}
				}
				centerpane.getChildren().setAll(historyPane);
			}
		});

		// display the bookmarks
		miBookmarks.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				ArrayList<Bookmark> bookmarks = new ArrayList<Bookmark>();

				BufferedReader file;
				try {
					file = new BufferedReader(new FileReader("bookmarks.txt"));
					String line;

					try {
						while ((line = file.readLine()) != null) {
							bookmarks.add(new Bookmark(line.split(",")[0], line.split(",")[1]));
						}
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				GridPane bookmarkPane = new GridPane();
				bookmarkPane.setAlignment(Pos.CENTER);
				if (bookmarks.isEmpty()) {
					bookmarkPane.add(new Text("There is no bookmarks!"), 0, 0);
				} else {
					bookmarkPane.add(new Text("Title"), 0, 0);
					bookmarkPane.add(new Text("URL"), 1, 0);
					for (int i = 0; i < bookmarks.size(); i++) {
						Text title = new Text(bookmarks.get(i).getTitle());
						Text url = new Text(bookmarks.get(i).getUrl());
						bookmarkPane.add(title, 0, i + 1);
						bookmarkPane.add(url, 1, i + 1);

					}

				}
				centerpane.getChildren().setAll(bookmarkPane);
			}
		});

		// set HBox style and add all
		tfTop.setPromptText("Type a URL");
		topHbox.setSpacing(5);
		HBox.setHgrow(tfTop, Priority.ALWAYS);
		topHbox.getChildren().addAll(btnBack, btnForward, btnRefresh, tfTop, btnSave, btnHome, splitMenuButton);
		return topHbox;
	}

// -------------------------------------- Center VBox ------------------------------------------------
	private VBox addCenterVBox() {
		VBox centerVbox = new VBox();

		// set the center image
		Label centerLb = new Label();
		Image centerLogo = new Image(getClass().getResourceAsStream("logo-128.png"));
		ImageView centerImv = new ImageView(centerLogo);
		Timeline rotate = new Timeline();
		centerLb.setGraphic(centerImv);
		KeyFrame keyFrame = new KeyFrame(Duration.millis(600), new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent t) {
				centerImv.setRotate(centerImv.getRotate() + 90);
			}
		});
		rotate.getKeyFrames().setAll(keyFrame);
		rotate.setCycleCount(Timeline.INDEFINITE);
		rotate.play();

		// set the center text field
		TextField centerTextField = new TextField();
		centerTextField.setPromptText("Type a URL");
		centerTextField.setMaxSize(500, 20);
		centerTextField.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				centerpane.getChildren().setAll(webView);
				// borderPane.setCenter(webView);
				engine.load("http://" + centerTextField.getText());
				tfTop.setText("http://" + centerTextField.getText());
			}
		});

		// set the search button
		Button btnSearch = new Button();
		Image searchIm = new Image(getClass().getResourceAsStream("search-16.png"));
		btnSearch.setGraphic(new ImageView(searchIm));
		btnSearch.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				centerpane.getChildren().setAll(webView);
				// borderPane.setCenter(webView);
				engine.load("http://" + centerTextField.getText());
				tfTop.setText("http://" + centerTextField.getText());
			}
		});

		// set VBox style and add all
		centerVbox.setSpacing(40);
		centerVbox.setAlignment(Pos.TOP_CENTER);
		centerVbox.getChildren().addAll(new Text(" "), centerLb, centerTextField, btnSearch);
		return centerVbox;
	}

// ---------------------------------------- bottom HBox ----------------------------------------------
	public HBox addBottomHBox() {
		HBox bottomHbox = new HBox();
		Button btnCustomize = createButton("customize");
		btnCustomize.setOnAction(e -> Popup.display());
		bottomHbox.setMaxHeight(20);

		bottomHbox.getChildren().add(btnCustomize);
		bottomHbox.setPadding(new Insets(20, 20, 5, 20));
		bottomHbox.setAlignment(Pos.BOTTOM_RIGHT);
		btnCustomize.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				final Stage dialog = new Stage();
				dialog.setTitle("Background Setup");
				Image dialogIcon = new Image(getClass().getResourceAsStream("color-16.png"));
				dialog.getIcons().add(dialogIcon);
				dialog.initModality(Modality.APPLICATION_MODAL);
				dialog.initOwner(primaryStage);
				VBox dialogVbox = new VBox(20);
				Button btnSet = new Button("Change background color");
				btnSet.setOnAction(e -> {
					dialog.close();
					setBackgoundColor();
				});
				dialogVbox.getChildren().addAll(new Text(""), createComboBoxbBackgroundColor(), btnSet);
				dialogVbox.setSpacing(50);
				dialogVbox.setAlignment(Pos.TOP_CENTER);
				Scene dialogScene = new Scene(dialogVbox, 300, 200);
				dialog.setScene(dialogScene);
				dialog.show();
			}
		});

		return bottomHbox;
	}

	public void setBackgoundColor() {
		switch (mode) {
		case "Blue":
			borderPane.setStyle("-fx-background-color: #81c483;");
			break;
		case "Pink":
			borderPane.setStyle("-fx-background-color: #ffaadd;");
			break;
		case "White":
			borderPane.setStyle("-fx-background-color: white;");
			break;
		default:
			// TO DO
			break;
		}
	}

	public ComboBox<String> createComboBoxbBackgroundColor() {
		ComboBox<String> cbBackground = new ComboBox<String>();
		cbBackground.setPrefSize(200, 35);
		cbBackground.getSelectionModel().select("Select a background color");
		Tooltip ttpBackground = new Tooltip();
		ttpBackground.setText("Please select a background color and then click on change button");
		ttpBackground.setFont(Font.font("Arial", FontWeight.BOLD, 16));
		cbBackground.setTooltip(ttpBackground);
		cbBackground.getItems().add("Blue");
		cbBackground.getItems().add("Pink");
		cbBackground.getItems().add("White");
		cbBackground.setOnAction((event) -> {
			mode = cbBackground.getSelectionModel().getSelectedItem();
		});
		return cbBackground;
	}

	// remove bookmark from the bookmark textfile
	// To Do
	private void removeLine(Bookmark bookmark) {
		try {
			BufferedReader file = new BufferedReader(new FileReader("bookmarks.txt"));
			String line;
			String input = "";
			while ((line = file.readLine()) != null) {
				// System.out.println(line);
				if (line.contains(bookmark.getTitle())) {
					line = "";
					System.out.println("Line deleted.");
				}
				input += line + '\n';
			}
			FileOutputStream File = new FileOutputStream("bookmarks.txt");
			File.write(input.getBytes());
			file.close();
			File.close();

		} catch (Exception e) {
			System.out.println("Problem reading file.");
		}
	}

	// Add bookmark to the bookmark textfile
	private void addLine() {
		try {
			Bookmark bookmark = new Bookmark(tfBookmarkTitle.getText(), tfBookmarkUrl.getText());
			BufferedReader file = new BufferedReader(new FileReader("bookmarks.txt"));
			String line;
			String input = "";
			while ((line = file.readLine()) != null) {
				input += line + '\n';
			}
			input += bookmark.getTitle() + "," + bookmark.getUrl();
			FileOutputStream File = new FileOutputStream("bookmarks.txt");
			File.write(input.getBytes());
			file.close();
			File.close();
		} catch (Exception e) {
			System.out.println("Problem reading file.");
		}
	}

	public TabPane addTabPane() {
		TabPane tb = new TabPane();
		tb.setPrefSize(1365, 768);
		Createfirsttab(tb);
		final Tab newtab = new Tab();
		// to do - add a plus image
		newtab.setText(" + ");
		Tooltip ttpnewTab = new Tooltip();
		ttpnewTab.setText("New tab");
		ttpnewTab.setFont(Font.font("Arial", FontWeight.BOLD, 16));
		newtab.setTooltip(ttpnewTab);
		newtab.setClosable(false);
		tb.getTabs().addAll(newtab);

		tb.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Tab>() {
			@Override
			public void changed(ObservableValue<? extends Tab> observable, Tab oldSelectedTab, Tab newSelectedTab) {
				if (newSelectedTab == newtab) {
					Tab tab = new Tab();
					tab.setText("New Tab");
					engine.locationProperty().addListener(new ChangeListener<String>() {
						@Override
						public void changed(ObservableValue<? extends String> observable, String oldValue,
								String newValue) {
							tfTop.setText(newValue);
						}
					});
					tab.setContent(new TabPage(toppane, centerpane, bottompane));
					final ObservableList<Tab> tabs = tb.getTabs();
					tabs.add(tabs.size() - 1, tab);
					tab.closableProperty().bind(Bindings.size(tabs).greaterThan(2));
					tb.getSelectionModel().select(tab);
				}
			}

		});
		return tb;
	}

	private Tab Createfirsttab(TabPane tb) {
		Tab stab = new Tab("Home");
		stab.setContent(new TabPage(toppane, centerpane, bottompane));
		tb.getTabs().add(stab);
		tb.getSelectionModel().select(stab);
		return stab;
	}

	public class TabPage extends VBox {
		private HBox toppane = new HBox();
		private VBox centerpane = new VBox();
		private HBox bottompane = new HBox();

		public TabPage(HBox toppane, VBox centrepane, HBox bottompane) {
			this.toppane = toppane;
			this.centerpane = centrepane;
			this.bottompane = bottompane;
			this.getChildren().addAll(toppane, centrepane, bottompane);
		}

		public HBox getToppane() {
			return toppane;
		}

		public void setToppane(HBox toppane) {
			this.toppane = toppane;
		}

		public VBox getCenterpane() {
			return centerpane;
		}

		public void setCenterpane(VBox centerpane) {
			this.centerpane = centerpane;
		}

		public HBox getBottompane() {
			return bottompane;
		}

		public void setBottompane(HBox bottompane) {
			this.bottompane = bottompane;
		}

	}

	private Tab createAndSelectNewTab(final TabPane tabPane, final String title) {
		Tab tab = new Tab(title);
		tab.setContent(new TabPage(toppane, centerpane, bottompane));
		final ObservableList<Tab> tabs = tabPane.getTabs();
		tab.closableProperty().bind(Bindings.size(tabs).greaterThan(2));
		tabs.add(tabs.size() - 1, tab);
		tabPane.getSelectionModel().select(tab);
		return tab;
	}

	public static void main(String[] args) {
		launch(args);
	}
}
